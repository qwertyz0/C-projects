﻿namespace lab_8__use_lab_5_
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddZavod = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbZavodInfo = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnAddZavod
            // 
            this.btnAddZavod.Location = new System.Drawing.Point(12, 204);
            this.btnAddZavod.Name = "btnAddZavod";
            this.btnAddZavod.Size = new System.Drawing.Size(101, 30);
            this.btnAddZavod.TabIndex = 1;
            this.btnAddZavod.Text = "Додати завод";
            this.btnAddZavod.UseVisualStyleBackColor = true;
            this.btnAddZavod.Click += new System.EventHandler(this.btnAddZavod_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(119, 204);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(101, 30);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Закрити";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbZavodInfo
            // 
            this.tbZavodInfo.FormattingEnabled = true;
            this.tbZavodInfo.Location = new System.Drawing.Point(12, 12);
            this.tbZavodInfo.Name = "tbZavodInfo";
            this.tbZavodInfo.Size = new System.Drawing.Size(686, 186);
            this.tbZavodInfo.TabIndex = 3;
            this.tbZavodInfo.SelectedIndexChanged += new System.EventHandler(this.tbZavodInfo_SelectedIndexChanged);
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 239);
            this.Controls.Add(this.tbZavodInfo);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAddZavod);
            this.MaximizeBox = false;
            this.Name = "fMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Лабораторна робота №8";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddZavod;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ListBox tbZavodInfo;
    }
}

