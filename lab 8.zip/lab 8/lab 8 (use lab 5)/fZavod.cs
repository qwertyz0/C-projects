﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_8__use_lab_5_
{
    public partial class fZavod : Form
    {
        public Zavod theZavod;


        public fZavod(Zavod z)
        {
            InitializeComponent();
            theZavod = z;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void fZavod_Load(object sendet, EventArgs e)
        {
            if (theZavod != null)
            {
                tbName.Text = theZavod.Name;
                tbCountry.Text = theZavod.Country;
                tbRegion.Text = theZavod.Region;
                tbPopulation.Text = theZavod.Population.ToString();
                tbYearSalary.Text = theZavod.YearSalary.ToString("0.00");
                tbSquare.Text = theZavod.Square.ToString("0.000");
                chbHasFireExit.Checked = theZavod.HasFireExit;
                chbHasKitchen.Checked = theZavod.HasKitchen;
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            theZavod.Name = tbName.Text.Trim();
            theZavod.Country = tbCountry.Text.Trim();
            theZavod.Region = tbRegion.Text.Trim();
            theZavod.Population = int.Parse(tbPopulation.Text.Trim());
            theZavod.YearSalary = double.Parse(tbYearSalary.Text.Trim());
            theZavod.Square = double.Parse(tbSquare.Text.Trim());
            theZavod.HasFireExit = chbHasFireExit.Checked;
            theZavod.HasKitchen = chbHasKitchen.Checked;

            DialogResult = DialogResult.OK;
        }
    }
}
