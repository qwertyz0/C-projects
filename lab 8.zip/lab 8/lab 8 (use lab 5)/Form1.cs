﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_8__use_lab_5_
{
    public partial class fMain : Form
    {
        BindingList<Zavod> zavods;

        public fMain()
        {
            InitializeComponent();

            zavods = new BindingList<Zavod>();

            tbZavodInfo.DataSource = zavods;
            tbZavodInfo.DisplayMember = "Info";
            tbZavodInfo.ValueMember = "Id";

            tbZavodInfo.SelectedIndexChanged += tbZavodInfo_SelectedIndexChanged;
        }

        void tbZavodInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

            Zavod zavod = (Zavod)tbZavodInfo.SelectedItem;
            MessageBox.Show(zavod.Id.ToString() + ". " + zavod.Name);

        }





        private void btnAddZavod_Click(object sender, EventArgs e)
        {
            Zavod zavod = new Zavod();

            fZavod ft = new fZavod(zavod);

            if (ft.ShowDialog() == DialogResult.OK)
            {
                zavods.Add(zavod);
                tbZavodInfo.DataSource = zavods;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Припинити роботу застосунку?",
                "Припинити роботу", MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question) == DialogResult.OK)
                Application.Exit();
        }


    }
}
