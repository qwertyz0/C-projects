﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_8__use_lab_5_
{
    public class Zavod
    {
        public string Name { get; set; }

        public string Country { get; set; }

        public string Region { get; set; }

        public int Population { get; set; }

        public double YearSalary { get; set; }

        public double Square { get; set; }

        public bool HasFireExit { get; set; }

        public bool HasKitchen { get; set; }
        public double GetYearSalary()
        {
            return YearSalary / Population;
        }

        public int Id { get; set; }
        public int Year { get; set; }

        public string Info { get {
                return " Страна: " + Country + " Имя: " + Name + "Регион:" + Region + " Число рабочих: " + Population + " Зарплата: " + YearSalary + " Площадь: " + Square +
 " Пожарный выход: " + HasFireExit + " Столовая: " + HasKitchen;} }
    }
}
